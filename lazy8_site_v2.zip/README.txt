# Lazy 8 Performance Horses Website

To upload to GitHub Pages:
1. Open your repository.
2. Tap 'Code' ▸ 'Upload file'.
3. Upload 'index.html' and 'styles.css'.
4. Commit changes.
5. Enable GitHub Pages (Settings ▸ Pages ▸ Source: main, folder: /root).
